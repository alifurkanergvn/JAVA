package entities;

public class User {
	private String firstName;
	private String lastName;
	private String identityNo;
	private int dateOfBirth;
	
	public User(String firstName, String lastName, String identityNo, int dateOfBirth) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.identityNo = identityNo;
		this.dateOfBirth = dateOfBirth;
		
		
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getIdentityNo() {
		return identityNo;
	}

	public void setIdentityNo(String identityNo) {
		this.identityNo = identityNo;
	}

	public int getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(int dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	
	
	

}
