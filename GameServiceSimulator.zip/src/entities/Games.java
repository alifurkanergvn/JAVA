package entities;



public class Games {
	private String gameName;
	private int gamePrice;
	
	
	
	public Games(String gameName, int gamePrice) {
		super();
		this.gameName = gameName;
		this.gamePrice = gamePrice;
	}
	
	

	public Games() {
		
	}



	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}

	public int getGamePrice() {
		return gamePrice;
	}

	public void setGamePrice(int gamePrice) {
		this.gamePrice = gamePrice;
	}
	
	
	
}
