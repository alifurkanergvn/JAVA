package entities;



public class Campaing  {

	
	private String discountName;
	private double rateOfDiscount;
	
	public Campaing(String discountName, double rateOfDiscount) {
		super();
		this.discountName = discountName;
		this.rateOfDiscount = rateOfDiscount;
	}

	public String getDiscountName() {
		return discountName;
	}

	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}

	public double getRateOfDiscount() {
		return rateOfDiscount;
	}

	public void setRateOfDiscount(double rateOfDiscount) {
		this.rateOfDiscount = rateOfDiscount;
	}
	
	

	

	
	
}
