import java.rmi.RemoteException;

import javax.swing.GroupLayout.Alignment;

import abstracts.ICheckService;
import adapter.MernisCheckService;
import concrete.CampaignManager;
import concrete.GamesManager;
import concrete.UserManager;
import entities.Campaing;
import entities.Games;
import entities.User;

public class main {

	public static void main(String[] args) throws NumberFormatException, RemoteException {
		
		User user1 = new User("Ali Furkan", "Erg�ven", "11111111111", 1997);
		
		UserManager userManager =new UserManager(new MernisCheckService());
		userManager.add(user1);
		
		
		Games games1 = new Games("Lord of the Rings Conquest", 150);
		
		GamesManager gamesManager = new GamesManager();
		gamesManager.gameSell(games1, user1);
		
		
		Campaing campaing = new Campaing("Y�lba�� indirimi", 20);
		
		
		
		CampaignManager campaignManager = new CampaignManager();
		campaignManager.addCampaign(campaing, games1);
		
		
		
		
		
		
		
		

	}

}
