package adapter;

import java.rmi.RemoteException;

import abstracts.ICheckService;
import entities.User;
import tr.gov.nvi.tckimlik.WS.KPSPublicSoapProxy;

public class MernisCheckService implements ICheckService{
	
	KPSPublicSoapProxy kpsPublicSoapProxy = new KPSPublicSoapProxy();

	@Override
	public boolean CheckIfRealPerson(User user) throws NumberFormatException, RemoteException {
		
		return kpsPublicSoapProxy.TCKimlikNoDogrula(Long.parseLong(user.getIdentityNo()), user.getFirstName().toUpperCase(),
				user.getLastName().toUpperCase(), user.getDateOfBirth());
		
		
	}

}
