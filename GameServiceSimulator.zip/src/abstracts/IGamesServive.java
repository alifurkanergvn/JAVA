package abstracts;

import entities.Games;
import entities.User;

public interface IGamesServive {
	void gameSell(Games games,User user);
	

}
