package abstracts;

import java.rmi.RemoteException;

import entities.User;

public interface IUserService {
	void add(User user) throws NumberFormatException, RemoteException;
	void update(User user);
	void delete(User user);
	
	

}
