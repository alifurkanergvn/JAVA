package abstracts;

import entities.Campaing;
import entities.Games;

public interface ICampaingService {
	void addCampaign(Campaing campaing, Games games);
	void deleteCampaign(Campaing campaing, Games games);
	void updateCampaign(Campaing campaing, Games games);

}
