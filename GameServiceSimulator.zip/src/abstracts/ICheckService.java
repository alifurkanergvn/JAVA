package abstracts;

import java.rmi.RemoteException;

import entities.User;

public interface ICheckService {
	boolean CheckIfRealPerson(User user) throws NumberFormatException, RemoteException;
	
	

}
