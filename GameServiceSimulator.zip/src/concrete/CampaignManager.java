package concrete;

import abstracts.ICampaingService;
import entities.Campaing;
import entities.Games;

public class CampaignManager implements ICampaingService{

	@Override
	public void addCampaign(Campaing campaing, Games games) {
		System.out.println(games.getGameName()+" oyununa % "+campaing.getRateOfDiscount()+" "
		+campaing.getDiscountName()+" indirimi uyguland�...Yeni �cret= "+(games.getGamePrice()-(games.getGamePrice()*campaing.getRateOfDiscount()/100)));
		
	}

	@Override
	public void deleteCampaign(Campaing campaing, Games games) {
		System.out.println("Kampanyan�z silindi.");
		
	}

	@Override
	public void updateCampaign(Campaing campaing, Games games) {
		System.out.println("Kampanyan�z g�ncellenmi�tir.");
		
	}

}
