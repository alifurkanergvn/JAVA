package concrete;

import abstracts.IGamesServive;
import entities.Games;
import entities.User;

public class GamesManager implements IGamesServive{

	@Override
	public void gameSell(Games games,User user) {
		System.out.println(games.getGameName()+" ,isimli oyun "+user.getFirstName()+" adl� kullan�c�ya sat�lm��t�r.");
		
	}
	

}
