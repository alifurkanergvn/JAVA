package concrete;

import java.rmi.RemoteException;

import abstracts.ICheckService;
import abstracts.IUserService;
import entities.User;

public class UserManager implements IUserService{

	private ICheckService iCheckService;

	public UserManager(ICheckService iCheckService) {
		super();
		this.iCheckService = iCheckService;
	}

	@Override
	public void add(User user) throws NumberFormatException, RemoteException {
		if (iCheckService.CheckIfRealPerson(user)== true) {
			System.out.println(user.getFirstName()+" "+user.getLastName()+" ba�ar�yla kaydolmu�tur.");
			
		}else {
			System.out.println("Kullan�c� bulunamam��t�r");
		}
		
	}

	@Override
	public void update(User user) {
		System.out.println(user.getFirstName()+" "+user.getLastName()+"isimli kullan�c� g�ncellenmi�tir");
		
	}

	@Override
	public void delete(User user) {
		System.out.println(user.getFirstName()+" "+user.getLastName()+"isimli kullan�c� silinmi�tir");
		
	}
	

}
