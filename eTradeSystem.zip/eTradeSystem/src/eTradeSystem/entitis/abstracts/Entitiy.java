package eTradeSystem.entitis.abstracts;

public interface Entitiy {

}
