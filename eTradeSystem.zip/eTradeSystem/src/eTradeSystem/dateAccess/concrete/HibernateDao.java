package eTradeSystem.dateAccess.concrete;

import java.util.ArrayList;
import java.util.List;

import eTradeSystem.dateAccess.abstracts.UserDao;
import eTradeSystem.entitis.concrete.User;

public class HibernateDao implements UserDao{

	
	List<User>users = new ArrayList<User>();
	
	@Override
	public void add(User user) {
		System.out.println("Kullan�c� hibernate ile eklendi "+user.getUserName()+user.getUserLastName());
		users.add(user);
		
	}

	@Override
	public void delete(User user) {
		System.out.println("Kullan�c� hibernate ile silindi "+user.getUserName()+user.getUserLastName());
		users.remove(user);
		
	}

	@Override
	public void update(User user) {
		System.out.println("Kullan�c� hibernate ile g�ncellendi "+user.getUserName()+user.getUserLastName());
		
	}


	@Override
	public List<User> getAll() {
		
		return null;
	}
	

}
