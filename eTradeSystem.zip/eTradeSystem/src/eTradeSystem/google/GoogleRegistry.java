package eTradeSystem.google;

public class GoogleRegistry {
	
	public void RegistryWithGoogle(String message) {
		System.out.println("Google hesap bilgileri=(*****)"+message);
	}
	

}
