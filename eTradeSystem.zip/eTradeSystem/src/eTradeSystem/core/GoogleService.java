package eTradeSystem.core;

public interface GoogleService {
	void RegistryExeptionWithApi(String message);

}
