package eTradeSystem.core;

import eTradeSystem.google.GoogleRegistry;

public class GoogleManagerAdapter implements GoogleService{

	@Override
	public void RegistryExeptionWithApi(String message) {
		GoogleRegistry googleRegistry = new GoogleRegistry();
		googleRegistry.RegistryWithGoogle(message);
		
		
	}

}
