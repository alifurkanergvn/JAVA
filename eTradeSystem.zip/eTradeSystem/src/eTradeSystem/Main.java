package eTradeSystem;

import eTradeSystem.business.abstracts.UserService;
import eTradeSystem.business.concrete.MailCheckManager;
import eTradeSystem.business.concrete.UserMenager;
import eTradeSystem.business.concrete.VerificationManager;
import eTradeSystem.core.GoogleManagerAdapter;
import eTradeSystem.core.GoogleService;
import eTradeSystem.dateAccess.concrete.HibernateDao;
import eTradeSystem.entitis.concrete.User;

public class Main {

	public static void main(String[] args) {

		User user = new User(0, "AliFurkan", "Erg�ven","alifurkan@gmail.com" ,"123456");
		User user1= new User(1, "�ahin", "K", "�ahin@yahoo.com", "121212");
		
		
		UserService userService = new UserMenager(new MailCheckManager(),new VerificationManager(),new HibernateDao()/*,new GoogleManagerAdapter() */ );
		userService.register(user);
		userService.register(user1);
		
		GoogleService googleService = new GoogleManagerAdapter();
		googleService.RegistryExeptionWithApi("  Google ile kay�dn�z olu�turulmu�tur.");
		
		

	}

}
