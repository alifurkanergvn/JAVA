package eTradeSystem.business.concrete;

import java.util.ArrayList;
import java.util.List;

import eTradeSystem.business.abstracts.MailCheckService;
import eTradeSystem.entitis.concrete.User;

public class MailCheckManager implements MailCheckService{

	List<String> userList = new ArrayList<String>();
	
	@Override
	public boolean checkVerifiedList(User user) {
		if(userList.contains(user.getUserMail())) {
			System.out.println(user.getUserMail()+" Girdi�iniz mail adresi kullan�lmaktad�r.");
			return false;
		}else {
			System.out.println(user.getUserMail()+" Girdi�iniz adres kullan�labilir.Ba�ka kullan�c� taraf�ndan hen�z al�nmam��");
			return true;
		}
	
	}

	@Override
	public void sendVerifiedMail(User user) {
		System.out.println(user.getUserMail()+" adresine do�rulama linki g�ndeldi.");
		
	}

	@Override
	public void addToVerifiedList(User user) {
		userList.add(user.getUserMail());
		System.out.println(userList);
		System.out.println(" Kullan�c� Email aktivasyonu yapm��t�r.");
		
	}

}
