package eTradeSystem.business.concrete;

import eTradeSystem.business.abstracts.UserService;
//import eTradeSystem.core.GoogleService;
import eTradeSystem.dateAccess.abstracts.UserDao;
import eTradeSystem.entitis.concrete.User;

public class UserMenager implements UserService{

	private MailCheckManager mailCheckManager;
	private VerificationManager verificationManager;
	private UserDao userDao;
	//private GoogleService googleService;
	
	public UserMenager(MailCheckManager mailCheckManager, VerificationManager verificationManager,
			UserDao userDao/*,GoogleService googleService*/) {
		super();
		this.mailCheckManager = mailCheckManager;
		this.verificationManager = verificationManager;
		this.userDao = userDao;
		//this.googleService = googleService;
	}
	
	@Override
	public void register(User user) {
		if(verificationManager.checkMail(user)&& mailCheckManager.checkVerifiedList(user) && verificationManager.checkName(user) && verificationManager.checkLastname(user)  
				 && verificationManager.checkPassword(user)) {
			
			mailCheckManager.sendVerifiedMail(user);
			mailCheckManager.addToVerifiedList(user);
			userDao.add(user);
			
			System.out.println("+++Kullan�c� kayd� ba�ar�l�+++");
			//googleService.RegistryExeptionWithApi("  Google ile kay�dn�z olu�turulmu�tur.");
			
		}else {
			System.out.println("---Kullan�c� kayd� ba�ar�s�z---");
		}
		
	}
	

}
