package eTradeSystem.business.concrete;

import eTradeSystem.business.abstracts.VerificationService;
import eTradeSystem.entitis.concrete.User;

public class VerificationManager implements VerificationService{

	@Override
	public boolean checkPassword(User user) {
		if(user.getUserPassword().length()>=6 && user.getUserPassword()!=null) {
			System.out.println("---�ifreniz uygundur---");
			return true;
		}else {
			System.out.println("---�ifreniz en az 6 karakter i�ermelidir---");
			return false;
		}
		
	}

	@Override
	public boolean checkMail(User user) {
		
		if(user.getUserMail().matches("[a-zA-Z0-9_\\-\\.]+[@][a-z]+[\\.][a-z]{2,3}")) {
			System.out.println(" Yazd���n�z Email adresi gerekli �artlar� sa�lamaktad�r...");
			return true;
		}else {
			System.out.println("Email adresiniz uygun de�ildir");
			return false;
		}
		
		
	}

	@Override
	public boolean checkName(User user) {
		if(user.getUserName().length()>=2) {
			System.out.println("---Ad�n�z uygundur---");
			return true;
		}else {
			System.out.println("---Kullan�c� ad�n�z en az 2 karakterden olu�mal�d�r---");
			return false;
		}
		
	}

	@Override
	public boolean checkLastname(User user) {
		if(user.getUserLastName().length()>=2) {
			System.out.println("---Soyad�n�z uygundur---");
			return true;
		}else {
			System.out.println("---Soyad�n�z en az 2 karakterden olu�mal�d�r---");
			return false;
		}
		
	}

}
