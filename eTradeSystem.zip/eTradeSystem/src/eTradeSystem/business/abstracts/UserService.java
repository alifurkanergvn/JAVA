package eTradeSystem.business.abstracts;

import eTradeSystem.entitis.concrete.User;

public interface UserService {
	
	void register(User user);
	
	

}
