package eTradeSystem.business.abstracts;

import eTradeSystem.entitis.concrete.User;

public interface MailCheckService {
	
	boolean checkVerifiedList(User user);
	void sendVerifiedMail(User user);
	void addToVerifiedList(User user);
	

}
