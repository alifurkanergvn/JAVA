package eTradeSystem.business.abstracts;

import eTradeSystem.entitis.concrete.User;

public interface VerificationService {
	boolean checkPassword(User user);
	boolean checkMail(User user);
	boolean checkName(User user);
	boolean checkLastname(User user);

}
