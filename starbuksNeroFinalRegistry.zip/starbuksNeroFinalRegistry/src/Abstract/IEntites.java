package Abstract;

public interface IEntites {

}
